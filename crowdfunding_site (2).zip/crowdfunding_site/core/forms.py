from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Project, Donation, Comment, ProjectDocument

class SignUpForm(UserCreationForm):
    pass

class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['name', 'description', 'goal_amount']

class DonationForm(forms.ModelForm):
    class Meta:
        model = Donation
        fields = ['amount']

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['text']

class DocumentForm(forms.ModelForm):
    class Meta:
        model = ProjectDocument
        fields = ['name', 'file']

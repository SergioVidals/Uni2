from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  
    path('proyectos/', views.project_list, name='project_list'),  
    path('signup/', views.signup, name='signup'), 
    path('my-projects/', views.my_projects, name='my_projects'),  
    path('project/<int:pk>/', views.project_detail, name='project_detail'), 
    path('create-project/', views.create_project, name='create_project'),  
    path('dashboard/', views.investor_dashboard, name='dashboard'),  
    path('project/<int:pk>/checkout/', views.create_checkout_session, name='create_checkout_session'),  
]

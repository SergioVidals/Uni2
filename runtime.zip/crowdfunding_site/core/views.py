from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.core.mail import send_mail
from django.conf import settings
import stripe

from .forms import SignUpForm, ProjectForm, DonationForm, CommentForm, DocumentForm
from .models import Project, Donation, Comment, ProjectDocument

stripe.api_key = settings.STRIPE_SECRET_KEY

def signup(request):
    form = SignUpForm(request.POST or None)
    if form.is_valid():
        user = form.save()
        login(request, user)
        return redirect('project_list')
    return render(request, 'registration/signup.html', {'form': form})

@login_required
def create_project(request):
    form = ProjectForm(request.POST or None)
    if form.is_valid():
        project = form.save(commit=False)
        project.owner = request.user
        project.save()
        return redirect('my_projects')
    return render(request, 'core/create_project.html', {'form': form})

@login_required
def my_projects(request):
    projects = Project.objects.filter(owner=request.user)
    return render(request, 'core/my_projects.html', {'projects': projects})

def project_list(request):
    projects = Project.objects.all()
    return render(request, 'core/project_list.html', {'projects': projects})

def project_detail(request, pk):
    project = get_object_or_404(Project, pk=pk)
    comments = Comment.objects.filter(project=project)
    documents = ProjectDocument.objects.filter(project=project)
    donations = Donation.objects.filter(project=project)
    total_donated = donations.aggregate(Sum('amount'))['amount__sum'] or 0

    donation_form = DonationForm()
    comment_form = CommentForm()
    doc_form = DocumentForm()

    if request.method == 'POST':
        if 'comment' in request.POST:
            comment_form = CommentForm(request.POST)
            if comment_form.is_valid():
                comment = comment_form.save(commit=False)
                comment.project = project
                comment.user = request.user
                comment.save()
                return redirect('project_detail', pk=project.id)

        elif 'upload_doc' in request.POST:
            doc_form = DocumentForm(request.POST, request.FILES)
            if doc_form.is_valid():
                document = doc_form.save(commit=False)
                document.project = project
                document.save()
                return redirect('project_detail', pk=project.id)

    return render(request, 'core/project_detail.html', {
        'project': project,
        'donation_form': donation_form,
        'comment_form': comment_form,
        'comments': comments,
        'documents': documents,
        'doc_form': doc_form,
        'stripe_publishable_key': settings.STRIPE_PUBLISHABLE_KEY,
        'total_donated': total_donated,
        'donations': donations,
    })

@login_required
def create_checkout_session(request, pk):
    project = get_object_or_404(Project, pk=pk)
    donation = Donation.objects.create(project=project, donor=request.user, amount=0)

    session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{
            'price_data': {
                'currency': 'usd',
                'product_data': {
                    'name': project.name,
                },
                'unit_amount': int(project.goal_amount * 100),
            },
            'quantity': 1,
        }],
        mode='payment',
        success_url=request.build_absolute_uri(f'/project/{pk}/?success=true'),
        cancel_url=request.build_absolute_uri(f'/project/{pk}/?canceled=true'),
    )

    donation.stripe_payment_intent = session.payment_intent
    donation.amount = project.goal_amount
    donation.save()
    return redirect(session.url, code=303)

@login_required
def investor_dashboard(request):
    donations = Donation.objects.filter(donor=request.user)
    total = donations.aggregate(Sum('amount'))['amount__sum'] or 0
    return render(request, 'core/investor_dashboard.html', {
        'donations': donations,
        'total': total,
    })

def home(request):
    return render(request, 'core/inicio.html')
